

export interface IPayload {
    id: string;
    email: string;
}